#!/bin/bash
#
# This is an install script for OpenSuSE-specific package updates.
#
set -ex

zypper update -y

exit 0
