#!/bin/bash
#
# This is an install script for Alpine-specific package updates.
#
set -ex

apk update

exit 0
